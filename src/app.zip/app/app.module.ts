import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { ServicesComponent } from './services/services.component';
import { ContactComponent } from './contact/contact.component';
import { GalleryComponent } from './gallery/gallery.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule } from '@angular/router';
import { ROUTING } from './app.routing';
import { BodyComponent } from './body/body.component';

import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { MarksComponent } from './marks/marks.component';
import { StudentDetailsComponent } from './student-details/student-details.component';
import { VideogalleryComponent } from './videogallery/videogallery.component';
import { VideoServiceService } from './video-service.service';
import {HttpModule} from "@angular/http";
import { FormsModule } from '@angular/forms';

import { FilterPipe} from './filter.pipe';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ServicesComponent,
    ContactComponent,
    GalleryComponent,
    HeaderComponent,
    FooterComponent,
    BodyComponent,
    MarksComponent,
    StudentDetailsComponent,
    VideogalleryComponent,
    FilterPipe
  ],
  imports: [
    BrowserModule,
    ROUTING,
    HttpModule,
    FormsModule
  ],
   providers: [{provide: LocationStrategy, useClass: HashLocationStrategy},VideoServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
