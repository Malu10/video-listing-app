﻿DIAGNAL PROGRAMMING TEST : 2017.09.01

1. Video Listing Layout Implementation
--------------------------------------

- Create mobile browser version of content Listing page shown in Exports folder using AngularJS/ReactJS or any other framework of your choice.

 

- This listing page contains a page title and a three column vertically scrolling grid which is not horizontally scrollable

- Redline folder details sizes for mobile app. 

Adapt this to mobile browser layout as necessary

- If anything is not specified in the Redline, make a best estimate on placing and sizing based on the Export folder images

-

 Slices folder has image assets which should all be used for this test. This includes poster images which are referred to in the JSON below. Note the images shown in the Exports folder are not the one to be used. The correct images are in the Slices folder.

- API folder has PAGEAPI-PAGE(#NUM).json which is used to provide data for the page (including specifying titles and poster images to be displayed). 

You will need to retrieve the data, JSON page at a time as the user scrolls down the page. 

Do not fetch all JSON pages at once, they should be loaded as the user navigates and approaches the end of their current data set. This lazy loading should be done in a seamless way without user noticing that additional data is loading (no pausing of scroll)

- 

Some content items on Page 3 have edge cases which you will need to think creatively how to solve without breaking the UI consistency


2.

 Search
---------

- Implement a search feature within the Video Listing Page. A search bar will show when user clicks / taps on search icon and will display the search results below the search bar. Review Hotstar or YouTube screen grab references in the search folder and on their websites / apps. These show example search bar implementations that can be considered for your implementation. 

You can develop your own UIUX but it should utilise a search bar. No design or layout specifications will be provided. 

- The Search feature should be functional and should search across the JSON API to show results.

- The Search feature should be visually consistent with the Video Listing page


3. Testing, Release & Hosting 
——————————————=

- 

Extra credit if you can follow TDD with associated test cases. 

- Write release notes explaining the features and any known issues

- Host the site or app somewhere and send a clear release email to the person who sent you this test. They should be able to access the site or app directly on their device with no technical assistance. 


General Advice
--------------

- Think about usability and ensure as close a match to provided designs as possible

- Use UI component / frameworks that you think are going to help speed up development but also perform well

- Write code that is easy to understand 

- Demonstrate your ability to write maintainable code

- Look at apps / sites like Netflix, Hotstar, YouTube for some ideas on the user experience 