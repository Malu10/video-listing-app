
import {Injectable} from '@angular/core';
import {  Http, Headers, RequestOptions,  Response} from '@angular/http';
 // import {Observable} from 'rxjs/Observable';
 // import {Subject} from 'rxjs/Subject';
 import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/toPromise';
import { RequestOptionsArgs } from '@angular/http';
import {IPosts} from './response';
@Injectable()
export class VideoServiceService {

  // private _postsURL = 'https://jsonplaceholder.typicode.com/posts/1';
  private _postsURL1 = 'assets/mock-data/CONTENTLISTINGPAGE-PAGE1.json';
  private _postsURL2 = 'assets/mock-data/CONTENTLISTINGPAGE-PAGE2.json';
  private _postsURL3 = 'assets/mock-data/CONTENTLISTINGPAGE-PAGE3.json';

  constructor(private http: Http) { }
    getPosts(pageNo): Observable<IPosts[]> {
      if (pageNo === 1) {
        return this.http
            .get(this._postsURL1)
            .map((response: Response) => {
                return <IPosts[]>response.json();
            })
            .catch(this.handleError);
      } else if (pageNo === 2) {
        return this.http
            .get(this._postsURL2)
            .map((response: Response) => {
                return <IPosts[]>response.json();
            })
            .catch(this.handleError);
      } else if (pageNo === 3) {
        return this.http
            .get(this._postsURL3)
            .map((response: Response) => {
                return <IPosts[]>response.json();
            })
            .catch(this.handleError);
      }





  }
    private handleError(error: Response) {
      return Observable.throw(error.statusText);
  }
  }


