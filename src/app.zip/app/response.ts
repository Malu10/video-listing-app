export interface IPosts {
    page: Page;
}

export interface Page {
    content: any;
}
