import { Component, OnInit , Input} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  sections: any;
  constructor(private router: Router) { }
    ngOnInit() {
      this.sections = [
        {name: 'Services',
          id: 'services',
          desc: 'We offer a full range of salon treatments and styling services provided bya team of professional stylists.',
          img: './../../assets/images/cards/contact.jpg'
        },
        {name: 'Gallery',
          id: 'gallery',
          desc: 'Checkout our works in unique photo gallery',
          img: './../../assets/images/cards/contact.jpg'
        },
        {name: 'Who we are',
          id: 'contact',
        desc: 'Contact us to know more about us ',
        img: './../../assets/images/cards/contact.jpg'
      }];
  }

  onCardClick(tab) {
     if (tab.id === 'services') {
      this.router.navigate(['services']);
    } else if (tab.id === 'gallery') {
      this.router.navigate(['gallery']);
    } else if (tab.id === 'contact') {
      this.router.navigate(['contact']);
    }
  }


}
